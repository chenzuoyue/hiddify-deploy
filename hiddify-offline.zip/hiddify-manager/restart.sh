#!/bin/bash
echo '模拟 restart...'
