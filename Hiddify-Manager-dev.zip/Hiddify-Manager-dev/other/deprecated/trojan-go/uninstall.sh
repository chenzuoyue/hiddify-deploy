systemctl kill trojan-go.service
systemctl disable trojan-go.service