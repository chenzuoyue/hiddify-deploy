




systemctl reload hiddify-caddy
systemctl start hiddify-caddy