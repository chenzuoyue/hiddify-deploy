
systemctl stop mtproxy > /dev/null 2>&1
systemctl disable mtproxy > /dev/null 2>&1
systemctl stop mtproto-proxy > /dev/null 2>&1
systemctl disable mtproto-proxy > /dev/null 2>&1
