systemctl stop hiddify-xray.service
systemctl disable hiddify-xray.service