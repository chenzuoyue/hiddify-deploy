此为 Hiddify Manager 的离线部署包，适用于 Ubuntu 22.04。
请确保已安装 Docker 与 Docker Compose。
执行 install.sh 开始部署，apply_configs.sh 可重载配置。