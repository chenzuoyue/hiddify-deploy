#!/bin/bash
echo "[Hiddify] 正在重新应用配置..."
docker compose restart
