#!/bin/bash
echo "[Hiddify] 开始部署..."
docker compose up -d
echo "[Hiddify] 部署完成！请访问 https://eacher.cn"
