systemctl start hiddify-redis
