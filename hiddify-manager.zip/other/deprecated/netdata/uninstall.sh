systemctl kill netdata
systemctl disable netdata