systemctl enable netdata
systemctl restart netdata
systemctl status netdata