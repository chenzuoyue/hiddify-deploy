systemctl stop --now wg-quick@warp
systemctl disable wg-quick@warp