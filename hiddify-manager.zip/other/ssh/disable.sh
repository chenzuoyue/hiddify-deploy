systemctl stop hiddify-ssh-liberty-bridge > /dev/null 2>&1
systemctl disable hiddify-ssh-liberty-bridge > /dev/null 2>&1