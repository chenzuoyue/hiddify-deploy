#!/bin/sh

export CREATE_EASYSETUP_LINK="true"
bash -c "$(curl -Lfo- https://raw.githubusercontent.com/hiddify/hiddify-manager/main/common/download_install.sh)"