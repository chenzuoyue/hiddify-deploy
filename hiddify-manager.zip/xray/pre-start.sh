#!/bin/bash
cd $( dirname -- "$0"; )
rm -rf run/*
rm -rf /dev/shm/hiddify-xtls-main.sock